﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Iniciar : MonoBehaviour
{
    public GameObject col1;
    // Start is called before the first frame update
    void Start()
    {
        col1.SetActive(false);
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    public void INICIAR()
    {
        col1.SetActive(true);
    }
}
