﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Tiro_Parabolico : MonoBehaviour
{
    Vector3 posicion;
    float angulo;
    float Vo;
    float k;
    float g = 9.8f;
    float t;
    bool control;
   // float euler = 2.718281828f;

    // Start is called before the first frame update
    void Start()
    {
        t = 0;
        posicion = new Vector3(0, 0, 0);
        control = true;
        
        

    }

    // Update is called once per frame
    void FixedUpdate()
    {
        
        if (control)
        {
            angulo = Dat_ANGULO.ang;
            angulo = angulo * 0.01745329252f;
            Vo = Dat_Vel.vel;
            k = Dat_k.dk;
            control = false;
        }
        
        t += 0.04166f;
        
        posicion = gameObject.GetComponent<Transform>().position;


        posicion.x = (Vo * Mathf.Cos(angulo) / k) * (1 - Mathf.Exp(-k * t));
        posicion.y = ((g + k * Vo * Mathf.Sin(angulo)) * (1 - Mathf.Exp(-k * t)) - g * k * t) / Mathf.Pow(k, 2);
        if (posicion.y>=0)
        {
 
            
            gameObject.GetComponent<Transform>().position = posicion;
        }



    }
}
