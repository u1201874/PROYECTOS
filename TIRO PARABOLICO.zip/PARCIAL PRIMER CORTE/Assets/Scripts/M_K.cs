﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class M_K : MonoBehaviour
{
    Text valor_Text;
    // Start is called before the first frame update
    void Start()
    {
        valor_Text = GetComponent<Text>();
        
    }

    // Update is called once per frame
    public void textUpdate(float value)
    {
        valor_Text.text = System.Math.Round(value, 2)+"";
    }
}
